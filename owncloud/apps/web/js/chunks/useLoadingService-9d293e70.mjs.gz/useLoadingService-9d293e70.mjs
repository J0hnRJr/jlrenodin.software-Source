import{k as e}from"./eventBus-bf81ca73.mjs";const i=()=>e("$loadingService");export{i as u};
