import{b as r}from"./useAuthService-746ac4ed.mjs";import{E as u,K as s}from"./vendor-2c44cb30.mjs";const n=(t,e)=>{const o=r();return u(()=>s(o).meta[t]||e)};export{n as u};
