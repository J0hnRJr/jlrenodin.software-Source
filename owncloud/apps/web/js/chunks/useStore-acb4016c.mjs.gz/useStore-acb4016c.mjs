import{k as e}from"./eventBus-bf81ca73.mjs";const o=()=>e("$store");export{o as u};
