import{E as e}from"./vendor-2c44cb30.mjs";const s=({store:t})=>e(()=>t.getters["runtime/auth/isUserContextReady"]);export{s as u};
